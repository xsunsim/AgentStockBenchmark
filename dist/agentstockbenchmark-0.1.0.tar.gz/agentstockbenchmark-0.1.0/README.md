# AgentStockBenchmark: The Clean-Room Engine (Github:AgentStockBenchmark)

[中文版本](./README_CN.md)

### THE ULTIMATE STRESS TEST FOR AGI
This is a live, tamper-proof arena testing whether the world's smartest AI agents can actually solve the ultimate stock prediction problem. We are not testing raw models in a sterile academic sandbox. We are testing the full autonomous loop—tools like Claude Code, Codex, and Gemini CLI—given clean data, a strict objective, and zero internet access. Every day, they are judged on one highly specific question: **which stock in the S&P 500 will have the best performance tomorrow?**

Most AI coding benchmarks are broken by data contamination. You never know if an AI "solved" a challenge or just memorized a GitHub repo. But nobody—not OpenAI, not Anthropic, not Google—has a chance to know **which stock in the S&P 500 will have the best performance tomorrow** during its training process. The future is the only uncontaminated test set.

**If you find this project interesting, please consider giving it a ⭐ Star and Forking the repository to test your own ideas!**

---

### JUST LOOKING FOR THE LEADERBOARD?
If you are here to see which AI makes the most money in this arena, check out our companion repository:
👉 **[AgentStockBenchmarkResults](https://github.com/xsunsim/AgentStockBenchmarkResults)**

The Results repository hosts the live leaderboard, the beautiful cumulative PnL charts, and the daily performance digests.

---

### THE "CLEAN ROOM" ARCHITECTURE
To ensure 100% integrity, this engine enforces a strict two-repository boundary:
1.  **This Repo (`AgentStockBenchmark`)**: The "Clean Room." It hosts the frozen agent logic, the prompts, and the orchestration engine. Once an agent generates a strategy, it is merged here and receives a permanent server-side timestamp.
2.  **Results Repo (`AgentStockBenchmarkResults`)**: The "Arena." It hosts the realized market data and the public leaderboard. 

**The Time Invariant**: An agent is only allowed to see a data snapshot truncated exactly at $t-1$ (yesterday). Its prediction for $t$ (today) must be frozen before market data for $t$ even exists.

---

### FOR DEVELOPERS & RESEARCHERS
This repository is an open-source engineering laboratory. We invite tech-heavy users to fork this engine and experiment with the "Autonomous Loop."

#### 1. Fork & Extend the Ideas
The true alpha in this benchmark isn't just the model—it's the **ideas**. We encourage you to:
*   **Implement New Portfolio Math**: Don't like our Linear Neutral ladder? Fork the engine and implement your own risk-parity or Kelly-criterion sizing logic in `stage3`.
*   **Agentic Scaffolding**: Modify the research workflow in `agentstockbenchmark.research` to test how different "chain-of-thought" or "self-reflection" loops affect strategy quality.
*   **Custom Universes**: The engine is built for the S&P 500, but the data-ingestion pipeline is flexible. Extend it to crypto, forex, or international equities.

#### 2. Prompt Engineering is Alpha
The biggest variable in performance is the scaffolding provided to the agent.
*   Check [STRATEGY_EDITORIAL.md](STRATEGY_EDITORIAL.md) to see how different model lineages (OpenAI, Anthropic, Google) responded to **[Prompt Version 20260517](prompts/20260517/prompt.md)**.
*   Experiment with the prompts in `prompts/`. Can you force a model to better understand overfitting? Can you scaffold it to build more robust volatility-normalization?

---

### ENGINE DOCUMENTATION
*   [SYSTEM.md](SYSTEM.md): Deep dive into the architecture, data contracts, and the $t-1 \to t \to t+1$ failure model.
*   [USAGE.md](USAGE.md): Full CLI cookbook for production, backfilling, and model migration.
*   [STRATEGY_EDITORIAL.md](STRATEGY_EDITORIAL.md): A detailed quantitative analysis of the strategies produced by each model under **[Prompt Version 20260517](prompts/20260517/prompt.md)**.

### QUICK START
```bash
# Clone the engine
git clone git@github.com:xsunsim/AgentStockBenchmark.git
cd AgentStockBenchmark
export PYTHONPATH=src

# List active prompts and strategies
python -m agentstockbenchmark stage1 list-prompts
python -m agentstockbenchmark stage1 list-strategies --prompt-id 20260517
```

### MCP SERVER (Model Context Protocol)
This engine can be run as an MCP server, allowing you to use it directly from an AI agent or a client like Claude Desktop.

#### Running the MCP Server
```bash
# Install dependencies
pip install .

# Start the server
asb-mcp
```

#### Available Tools
*   `get_leaderboard`: Retrieves the current production leaderboard (auto-syncs with GitHub).
*   `list_active_prompts`: Lists IDs of available strategy generation prompts.
*   `list_available_strategies`: Lists all strategies currently in the production system.
*   `get_top_positions`: Returns the top long/short stock positions for a model on a specific date.
*   `run_strategy_on_date`: Runs a specific strategy for a single date (faster than full daily run).
*   `refresh_market_data`: Downloads and prepares market data for a specific date.
*   `create_research_workspace`: Sets up an isolated area for strategy generation.
*   `run_research_backtest`: Runs a backtest for a specific research run.
*   `analyze_results`: Summarizes performance of a research run.
*   `promote_strategy`: Promotes a successful research strategy to production.
*   `run_production_daily`: Executes the full daily production pipeline.

### FOR AI AGENTS (OPERATIONAL GUIDE)
If you are an AI agent using this MCP, follow these best practices for a seamless experience:

1.  **Checking Performance**: Always start with `get_leaderboard` to see which model lineages are currently winning.
2.  **Predicting the Future**: To get positions for the *next* trading day, use `get_top_positions` with the `target_trading_date` set to the next day. The tool will automatically handle the "Autopilot" sequence (syncing data and running strategies).
3.  **Experimental Workflow**:
    *   `list_active_prompts` to find a starting point.
    *   `create_research_workspace` to set up a lab.
    *   Generate a new `strategy.py` file based on the prompt.
    *   `run_research_backtest` to verify your idea.
    *   `analyze_results` to see if your Sharpe ratio beats the current leaderboard.
4.  **Data Latency**: Market data for "Today" is usually available 15 minutes after the New York market close (4:15 PM ET).

### WHAT WE ARE NOT
We are not a hedge fund. We are not a stock recommendation service. **Use it at your own risk.**

We care if Codex beats Claude Code—not if AAPL beats NVDA tomorrow.
